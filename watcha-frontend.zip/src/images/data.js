import img1 from "./1.jpg";
import img2 from "./2.jpg";
import img3 from "./3.jpg";
import img4 from "./4.jpg";
import img5 from "./5.jpg";
import img6 from "./6.jpg";
import img7 from "./32.jpg";
const data = [
    {
        id: 1,
        profileImagePath: img1,
        name: "영화번역가 황석희",
        description: "(기본)영화번역가, 남편, 버스커",
    },
    {
        id: 2,
        profileImagePath: img2,
        name: "영화평론가 장보고",
        description: "영화 평론가입니다",
    },
    {
        id: 3,
        profileImagePath: img3,
        name: "왕건",
        description: "영화 평론가입니다",
    },
    {
        id: 4,
        profileImagePath: img4,
        name: "궁예",
        description: "영화 평론가입니다",
    },
    {
        id: 5,
        profileImagePath: img5,
        name: "견훤",
        description: "영화 평론가입니다",
    },
    {
        id: 6,
        profileImagePath: img6,
        name: "홍길동",
        description: "영화 평론가입니다",
    },
    {
        id: 7,
        profileImagePath: img7,
        name: "둘리",
        description: "영화 평론가입니다",
    },
];

export default data;
