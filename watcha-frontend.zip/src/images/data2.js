const data2 = [
    {
        id: 1,
        description: "(기본)영화번역가, 남편, 버스커",
    },
    {
        id: 2,
        description: "영화 평론가입니다",
    },
    {
        id: 3,
        description: "영화 평론가입니다",
    },
    {
        id: 4,
        description: "영화 평론가입니다",
    },
    {
        id: 5,
        description: "영화 평론가입니다",
    },
    {
        id: 6,
        description: "영화 평론가입니다",
    },
    {
        id: 7,
        description: "영화 평론가입니다",
    },
];

export default data2;
