import React from "react";
import styled from "styled-components";

const Wrapper = styled.div`
    height: 200px;
`;

const Rank = () => {
    return <Wrapper>맨 마지막 컬렉션</Wrapper>;
};

export default Rank;
