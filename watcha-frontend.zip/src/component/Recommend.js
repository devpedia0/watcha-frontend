import React from "react";
import styled from "styled-components";

const Wrapper = styled.div`
    height: 200px;
`;

const Rank = () => {
    return <Wrapper>중간 7개 추천목록</Wrapper>;
};

export default Rank;
