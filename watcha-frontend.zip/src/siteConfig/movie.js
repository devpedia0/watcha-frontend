const data = [
    {
        category: "카테고리",
        contents: "컨테츠",
        description: "설명",
        elaboration: "string",
        mainTitle: "제목",
        subtitle: "부제목",
        page: 212,
        productionDate: new Date(),
        roleList: [
            {
                participantId: 1001,
                characterName: "극중이름",
                role: "조연",
            },
        ],
        tagList: [41],
    },
    {
        category: "카테고리",
        contents: "컨테츠",
        description: "설명",
        elaboration: "string",
        mainTitle: "제목",
        subtitle: "부제목",
        page: 212,
        productionDate: new Date(),
        roleList: [
            {
                participantId: 1001,
                characterName: "극중이름",
                role: "조연",
            },
        ],
        tagList: [41],
    },
    {
        category: "카테고리",
        contents: "컨테츠",
        description: "설명",
        elaboration: "string",
        mainTitle: "제목",
        subtitle: "부제목",
        page: 212,
        productionDate: new Date(),
        roleList: [
            {
                participantId: 1001,
                characterName: "극중이름",
                role: "조연",
            },
        ],
        tagList: [41],
    },
];

export default data;
