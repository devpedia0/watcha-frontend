import React, { useState, useEffect, useCallback, useRef } from "react";
import styled from "styled-components";
import { CardCollection, CardListSlick, CardPoster } from "../../components";
import dummy from "../../utils/dummy";

const collectionItem = {
    posters: [
        process.env.PUBLIC_URL + "/images/1.jpg",
        process.env.PUBLIC_URL + "/images/2.jpg",
        process.env.PUBLIC_URL + "/images/3.jpg",
        process.env.PUBLIC_URL + "/images/4.jpg",
    ],
    title: "컬렉션 테스트",
};

const Wrapper = styled.div`
    display: flex;
    flex-direction: column;
    min-height: calc(100vh - 0px);
    margin-top: 74px;
    width: 100%;

    @media only screen and (min-width: 600px) {
        min-height: calc(100vh - 343px);
        margin-top: 74px;
    }

    @media only screen and (min-width: 760px) {
        margin-top: 80px;
    }

    @media only screen and (min-width: 1100px) {
        margin-top: 86px;
    }
`;

const Home = () => {
    const [state, setState] = useState({
        dataCtg: "recommend",
        loading: false,
        rank: {},
        tag: {},
        score: {},
        collection: {},
        award: {},
        popular: {},
    });

    const infiniteScroll = useCallback(() => {
        let elem = document.documentElement;
        let body = document.body;

        let scrollHeight = Math.max(elem.scrollHeight, body.scrollHeight);
        let scrollTop = Math.max(elem.scrollTop, body.scrollTop);
        let clientHeight = elem.clientHeight;

        if (scrollTop >= scrollHeight - clientHeight) {
            setState((prevState) => ({
                ...prevState,
                scrolling: true,
            }));
        }
    }, []);

    // const getDataAPI = () => {
    //     // const res = await api.get(fetchURL);
    //     const res = dummy;

    // }

    useEffect(() => {
        window.addEventListener("scroll", infiniteScroll);

        return () => window.removeEventListener("scroll", infiniteScroll);
    }, [infiniteScroll]);

    return (
        <Wrapper>
            <CardListSlick num="1" fetchURL="" card={CardPoster} />
            <CardListSlick num="2" fetchURL="" card={CardPoster} />
            <CardListSlick num="3" fetchURL="" card={CardPoster} />
            <CardListSlick num="4" fetchURL="" card={CardPoster} />

            <CardListSlick
                num="5"
                fetchURL=""
                card={CardPoster}
                size="medium"
            />
            {state.scrolling && <div>로딩중!!!!!!</div>}
            {/* <CardListSlick
                num="5"
                fetchURL=""
                card={CardPoster}
                size="medium"
            />
            <CardListSlick
                num="6"
                fetchURL=""
                card={CardPoster}
                size="medium"
            />
            <CardListSlick
                num="7"
                fetchURL=""
                card={CardCollection}
                size="medium"
            /> */}
        </Wrapper>
    );
};

export default Home;
