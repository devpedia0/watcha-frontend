import React from "react";
import FormLayout from "../../layouts/FormLayout";
import useInputs from "../../Hooks/useInputs";

// components
import FormContent from "../../component/Form/FormContent";
import FormBook from "../../component/Form/FormBook";
import FormRoleList from "../../component/Form/FormRoleList";
import FormTagList from "../../component/Form/FormTagList";

const initialValue = {
    file: "",
    mainTitle: "",
    category: "",
    productionDate: "",
    description: "",

    subtitle: "",
    contents: "",
    page: "",
    elaboration: "",

    roleList: [],
    tagList: [],
};

const PageBook = () => {
    const pathname = "";
    const { inputs, setInputs, onChange, onsubmit } = useInputs(initialValue);

    const handleSubmit = () => {
        onsubmit(pathname, inputs);
    };

    return (
        <FormLayout>
            <FormContent inputs={inputs} onChange={onChange} />
            <FormBook inputs={inputs} onChange={onChange} />
            <FormRoleList roleList={inputs.roleList} setRoleList={setInputs} />
            <FormTagList tagList={inputs.tagList} setTagList={setInputs} />
            <button
                type="button"
                className="btn btn-primary mt-3"
                onClick={handleSubmit}
            >
                submit
            </button>
        </FormLayout>
    );
};

export default PageBook;
