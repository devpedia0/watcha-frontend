import React from "react";
import FormLayout from "../../layouts/FormLayout";
import useInputs from "../../Hooks/useInputs";

// components
import FormContent from "../../component/Form/FormContent";
import FormMovie from "../../component/Form/FormMovie";
import FormRoleList from "../../component/Form/FormRoleList";
import FormTagList from "../../component/Form/FormTagList";

const initialValue = {
    file: "",
    mainTitle: "",
    category: "",
    productionDate: "",
    description: "",
    originTitle: "",
    countryCode: "",
    runningTimeInMinutes: "",
    bookRate: "",
    totalAudience: "",
    isWatchaContent: "",
    isNetflixContent: "",
    roleList: [],
    tagList: [],
};

const PageMovie = () => {
    const { inputs, setInputs, onChange, onSubmit } = useInputs(initialValue);

    const handleSubmit = () => {
        // const { file, ...body } = inputs;
        // const formData = new FormData();
        // formData.append("file", inputs.file);
        // formData.append(
        //     "body",
        //     new Blob([JSON.stringify(body)], { type: "application/json" })
        // );
        // onSubmit('/admin/movies', inputs);
    };
    return (
        <FormLayout>
            <FormContent inputs={inputs} onChange={onChange} />
            <FormMovie inputs={inputs} onChange={onChange} />
            <FormRoleList roleList={inputs.roleList} setRoleList={setInputs} />
            <FormTagList tagList={inputs.tagList} setTagList={setInputs} />
            <button
                type="button"
                className="btn btn-primary mt-3"
                onClick={handleSubmit}
            >
                submit
            </button>
        </FormLayout>
    );
};

export default PageMovie;
